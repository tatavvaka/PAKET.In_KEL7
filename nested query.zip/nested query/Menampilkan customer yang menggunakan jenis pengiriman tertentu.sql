SELECT nama_customer
FROM customer
WHERE id_customer IN (
    SELECT id_customer
    FROM transaksi
    WHERE id_jenis = (
        SELECT id_jenis FROM jenis WHERE jenis_pengiriman = 'Hemat'
    )
);

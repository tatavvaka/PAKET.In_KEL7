SELECT *
FROM transaksi
WHERE id_harga IN (
    SELECT id_harga 
    FROM harga
    WHERE harga > (SELECT AVG(harga) FROM harga)
);

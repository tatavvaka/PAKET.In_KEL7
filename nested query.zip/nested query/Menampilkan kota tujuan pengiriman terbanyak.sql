SELECT kota
FROM kota
WHERE id_kota = (
    SELECT id_kota_tujuan
    FROM transaksi
    GROUP BY id_kota_tujuan
    ORDER BY COUNT(*) DESC
    LIMIT 1
);

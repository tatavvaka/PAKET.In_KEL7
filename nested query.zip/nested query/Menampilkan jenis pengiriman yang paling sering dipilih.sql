SELECT jenis_pengiriman
FROM jenis
WHERE id_jenis = (
    SELECT id_jenis
    FROM transaksi
    GROUP BY id_jenis
    ORDER BY COUNT(*) DESC
    LIMIT 1
);

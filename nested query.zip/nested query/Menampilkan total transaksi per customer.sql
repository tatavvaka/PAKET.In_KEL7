SELECT 
    c.nama_customer,
    (SELECT SUM(total)
     FROM transaksi t
     WHERE t.id_customer = c.id_customer) AS total_transaksi
FROM customer c;

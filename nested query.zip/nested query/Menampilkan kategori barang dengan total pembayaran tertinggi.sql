SELECT kategori
FROM kategori
WHERE id_kategori = (
    SELECT id_kategori 
    FROM transaksi
    ORDER BY total DESC
    LIMIT 1
);

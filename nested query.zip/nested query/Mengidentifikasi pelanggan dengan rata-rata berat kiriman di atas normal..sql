SELECT nama_customer
FROM customer
WHERE id_customer IN (
    SELECT id_customer
    FROM transaksi
    WHERE berat > (SELECT AVG(berat) FROM transaksi)
);

SELECT 
    t.no_resi,
    (SELECT nama_customer FROM customer c WHERE c.id_customer = t.id_customer) AS nama_customer,
    t.total
FROM transaksi t
ORDER BY t.total DESC
LIMIT 5;

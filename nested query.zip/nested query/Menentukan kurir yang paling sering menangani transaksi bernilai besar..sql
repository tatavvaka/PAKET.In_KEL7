SELECT nama_kurir
FROM kurir
WHERE id_kurir = (
    SELECT id_kurir 
    FROM transaksi
    ORDER BY total DESC
    LIMIT 1
);

SELECT *
FROM transaksi
WHERE id_kota_asal = (
    SELECT id_kota FROM kota WHERE kota = 'Jakarta'
);

SELECT metode_pembayaran
FROM metode
WHERE id_metode = (
    SELECT id_metode
    FROM transaksi
    GROUP BY id_metode
    ORDER BY COUNT(*) DESC
    LIMIT 1
);

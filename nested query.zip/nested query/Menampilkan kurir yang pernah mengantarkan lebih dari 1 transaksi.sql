SELECT nama_kurir
FROM kurir
WHERE id_kurir IN (
    SELECT id_kurir
    FROM transaksi
    GROUP BY id_kurir
    HAVING COUNT(no_resi) > 
);

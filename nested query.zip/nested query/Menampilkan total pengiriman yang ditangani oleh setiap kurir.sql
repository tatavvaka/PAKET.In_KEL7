SELECT 
    k.nama_kurir,
    (SELECT COUNT(*) 
     FROM transaksi t 
     WHERE t.id_kurir = k.id_kurir) AS total_pengantaran
FROM kurir k;

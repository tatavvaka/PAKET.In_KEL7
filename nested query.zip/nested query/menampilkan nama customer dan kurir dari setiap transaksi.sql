SELECT 
    t.no_resi,
    (SELECT c.nama_customer 
     FROM customer c 
     WHERE c.id_customer = t.id_customer) AS nama_customer,
    (SELECT k.nama_kurir 
     FROM kurir k 
     WHERE k.id_kurir = t.id_kurir) AS nama_kurir,
    t.tanggal_pengiriman
FROM transaksi t;